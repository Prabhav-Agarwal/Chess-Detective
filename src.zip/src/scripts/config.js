export const SEARCH_DEPTH = 20;
export const INIT_CP = 0;
export const MATE_CP = 1000;
export const ONLY_MOVE_THRESHOLD_PCTG = 10;
export const LOSING_MAX_PCTG = 35;
export const EQUAL_MIN_PCTG = 45;
export const EQUAL_MAX_PCTG = 55;
export const WINNING_MIN_PCTG = 70;
export const COMP_WINNING_PCTG = 90;
export const EXPECTEDSCORE_TABLE = {
  best: {
    lowerLim: 0.0,
    upperLim: 0.0,
  },

  excellent: {
    lowerLim: 0.0,
    upperLim: 0.02,
  },

  good: {
    lowerLim: 0.02,
    upperLim: 0.05,
  },

  inaccuracy: {
    lowerLim: 0.05,
    upperLim: 0.1,
  },

  mistake: {
    lowerLim: 0.1,
    upperLim: 0.2,
  },

  blunder: {
    lowerLim: 0.2,
    upperLim: 1.0,
  },
};
