import * as gameModel from "../models/gameModel.js";
import { EXPECTEDSCORE_TABLE } from "../config.js";
import { ONLY_MOVE_THRESHOLD_PCTG } from "../config.js";
import { LOSING_MAX_PCTG } from "../config.js";
import { EQUAL_MIN_PCTG } from "../config.js";
import { EQUAL_MAX_PCTG } from "../config.js";
import { WINNING_MIN_PCTG } from "../config.js";
import { COMP_WINNING_PCTG } from "../config.js";

const classifyMovesStandard = function (expectedScore) {
  if (expectedScore < 0) return "best";
  const classificationTypes = Object.keys(EXPECTEDSCORE_TABLE);
  for (let classification of classificationTypes) {
    const { lowerLim, upperLim } = EXPECTEDSCORE_TABLE[classification];

    if (expectedScore >= lowerLim && expectedScore <= upperLim) {
      return classification;
    }
  }
};

const isMoveGreat = function (
  playedMove,
  bestMove,
  expectedScore,
  beforeWinPercentageLine1,
  beforeWinPercentageLine2,
) {
  //base clause 1 : great move can either be best or excellent

  const { upperLim } = EXPECTEDSCORE_TABLE.excellent;
  if (expectedScore > upperLim) {
    return false;
  }

  //base clause 3: only enter if played move is best move of engine.
  if (playedMove !== bestMove) {
    return false;
  }

  // base clause 2 : great move classification is not required if player was already completely winning
  if (beforeWinPercentageLine1 > COMP_WINNING_PCTG) {
    return false;
  }

  //Only-Move Test : To check if there is only one good move in the position.
  const gapWinPercentageLine1Line2 =
    beforeWinPercentageLine1 - beforeWinPercentageLine2;
  if (gapWinPercentageLine1Line2 > ONLY_MOVE_THRESHOLD) {
    return true;
  }

  // TRANSITION TEST : for LOSS to DRAW and DRAW to WINNING

  if (
    beforeWinPercentageLine2 <= LOSING_MAX_PCTG &&
    beforeWinPercentageLine1 >= EQUAL_MIN_PCTG
  ) {
    return true;
  }
  if (
    beforeWinPercentageLine2 > EQUAL_MIN_PCTG &&
    beforeWinPercentageLine2 < EQUAL_MAX_PCTG &&
    beforeWinPercentageLine1 >= WINNING_MIN_PCTG
  ) {
    return true;
  }

  return false;
};


const isMoveBrilliant(){
  
}








export const classifyMoves = function () {
  const arr = [""];
  arr.push(
    ...gameModel.game.expectedPointsArr.map((expectedScore, i) => {
      return classifyMovesStandard(
        i % 2 === 0 ? expectedScore : -expectedScore,
      );
    }),
  );
  console.log(arr);
};
